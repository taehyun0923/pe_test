# Ransomware
Ransomeware attack on Linux Operating System

This is an educational project . Do not misuse it as it can lead you to severe punishment.
Guide for the ransomware. Follow the video in the link.
https://youtu.be/UsURbmlgxgI
